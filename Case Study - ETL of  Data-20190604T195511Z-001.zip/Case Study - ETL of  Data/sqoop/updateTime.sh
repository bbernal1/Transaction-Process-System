sqoop job \
--meta-connect jdbc:hsqldb:hsql://localhost:16000/sqoop \
--delete updateTime \

sqoop job \
--meta-connect jdbc:hsqldb:hsql://localhost:16000/sqoop \
--create updateTime \
-- import \
--connect jdbc:mysql://localhost/cdw_sapp --driver com.mysql.jdbc.Driver \
-m 1 \
--query \
"SELECT concat(YEAR,lpad(MONTH,2,'0'),lpad(DAY,2,'0')) AS 'TIMEID',
LPAD(DAY,2,'0') AS 'DAY',
LPAD(MONTH,2,'0') AS 'MONTH',
CASE
	WHEN MONTH IN (1,2,3) THEN 'Q1'
	WHEN MONTH IN (4,5,6) THEN 'Q2'
	WHEN MONTH IN (7,8,9) THEN 'Q3'
	WHEN MONTH IN (10,11,12) THEN 'Q4'
END AS Quarter,
YEAR,
LAST_UPDATED
FROM
cdw_sapp.cdw_sapp_creditcard
WHERE \$CONDITIONS" \
--append \
--incremental lastmodified \
--target-dir /Credit_Card_System/CDW_SAPP_D_TIME/ \
--check-column LAST_UPDATED \
--last-value '0000-00-00 00:00:00' \
--fields-terminated-by '\t' \

sqoop job \
--meta-connect jdbc:hsqldb:hsql://localhost:16000/sqoop \
--exec updateTime