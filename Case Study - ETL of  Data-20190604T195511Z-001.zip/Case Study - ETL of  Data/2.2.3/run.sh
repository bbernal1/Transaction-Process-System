hadoop fs -put -f workflow.xml /unoptimized_oozie/
hadoop fs -put -f coordinator.xml /unoptimized_oozie/

oozie job -oozie http://localhost:11000/oozie  -config  job.properties  -run