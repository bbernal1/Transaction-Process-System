hive -f createDatabase.hql 

hadoop fs -put -f CDW_SAPP_D_BRANCH.hql /unoptimized_oozie
hadoop fs -put -f CDW_SAPP_F_CREDIT_CARD.hql /unoptimized_oozie
hadoop fs -put -f CDW_SAPP_D_TIME.hql /unoptimized_oozie
hadoop fs -put -f CDW_SAPP_D_CUSTOMER.hql /unoptimized_oozie
hadoop fs -put -f coordinator.xml /unoptimized_oozie
hadoop fs -put -f workflow.xml /unoptimized_oozie