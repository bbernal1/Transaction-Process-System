#Queries 2.1.1
#1
SELECT cdw_sapp_creditcard.*, cdw_sapp_customer.CUST_ZIP
FROM cdw_sapp_customer INNER JOIN cdw_sapp_creditcard ON cdw_sapp_creditcard.credit_card_no = cdw_sapp_customer.credit_card_no 
AND cdw_sapp_creditcard.CUST_SSN = cdw_sapp_customer.SSN
WHERE cdw_sapp_customer.cust_zip = '39120' AND cdw_sapp_creditcard.MONTH = 12 AND cdw_sapp_creditcard.YEAR = 2018	
ORDER BY cdw_sapp_creditcard.DAY DESC;


#2
SELECT sum(transaction_value), count(transaction_value)
from cdw_sapp_creditcard
where transaction_type = 'bills';


#3
SELECT sum(transaction_value), count(transaction_value)
FROM cdw_sapp_creditcard inner join cdw_sapp_branch on cdw_sapp_creditcard.branch_code = cdw_sapp_branch.BRANCH_CODE
where BRANCH_STATE = 'NY';

#2.1.2
#1
#HIDE LAST_UPDATED TIMESTAMP
SELECT cdw_sapp_customer.*
from cdw_sapp_customer
WHERE SSN = '123459988' AND CREDIT_CARD_NO = '4210653349028689';

#2
UPDATE cdw_sapp_customer SET FIRST_NAME = 'Amalia', LAST_NAME = 'Campos' 
WHERE SSN = '123459988' AND CREDIT_CARD_NO = '4210653349028689';

#3) To generate monthly bill for a credit card number for a given month and year.
SELECT *
FROM cdw_sapp_creditcard 
WHERE CUST_SSN ='123459988' AND CREDIT_CARD_NO = '4210653349028689' AND YEAR = 2018 AND MONTH = 1
ORDER BY DAY DESC;
 
-- 4) To display the transactions made by a customer between two dates. 
-- Order by year, month, and day in descending order. 
SELECT *
FROM cdw_sapp_creditcard
WHERE (CUST_SSN ='123459988' AND CREDIT_CARD_NO = '4210653349028689') and (date_format(str_to_date(concat(day,'/',month, '/', year) ,'%d/%m/%Y'),'%Y/%m/%d') 
between date_format(str_to_date(concat(20,'/',2, '/', 2018) ,'%d/%m/%Y'),'%Y/%m/%d') 
and date_format(str_to_date(concat(10,'/',4, '/', 2018) ,'%d/%m/%Y'),'%Y/%m/%d'))
order by year desc, month desc, day desc;

