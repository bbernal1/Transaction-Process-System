# -*- coding: utf-8 -*-


import numpy as np
import matplotlib.pyplot as plt

fileHandler = open("query2.txt", "r")
lines = fileHandler.readlines()
fileHandler.close()
x = ["1", "2", "3", "4"]
y = [[],[],[],[],[],[],[]]


#for i in range(7):
 #   y.append(range (i,0))
    
j = 0;
for i in lines:
    vals = i.split()
    y[j%7].append(float(vals[2]))
    j+=1
    
n = len(x)
ind = np.arange(n)    # the x locations for the groups
width = 0.75       # the width of the bars: can also be len(x) sequence

plt.subplots(figsize=(20,15))

total = []
legendList = []
for i in range(0,7):
    if i == 0:
        legendList.append(plt.bar(ind,y[i], width))
        total = y[i]
    else:
        legendList.append(plt.bar(ind,y[i], width, bottom = total))
        total += np.array(y[i])


plt.xticks(ind, x, fontsize=15)
plt.yticks(np.arange(0, 850000, step=25000))
plt.ylim(bottom=0, top = 850000)


plt.xlabel("Quarter",labelpad=30,fontsize=20)
plt.ylabel("Total Transaction Value (USD)",labelpad=30,fontsize=20)
plt.title("Total Transaction Value for Each Transaction Type by Quarter", pad=20, fontsize=20)
plt.legend((legendList[0][0], legendList[1][0], legendList[2][0], legendList[3][0], legendList[4][0], legendList[5][0], legendList[6][0]),("Bills", "Education", "Entertainment", "Gas", "Grocery","Healthcare","Test"),loc=1,fontsize ="xx-large")
plt.show()