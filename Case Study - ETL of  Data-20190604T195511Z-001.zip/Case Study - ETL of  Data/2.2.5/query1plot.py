# -*- coding: utf-8 -*-


import numpy as np
import matplotlib.pyplot as plt

fileHandler = open("query1.txt", "r")
lines = fileHandler.readlines()
fileHandler.close()
x = []
y = []

for i in lines:
    vals = i.split()
  
    x.append(vals[0].zfill(5))
    y.append(float(vals[1]))
    
n = len(x)

ind = np.arange(n)
width = 0.75      

plt.subplots(figsize=(20,13))
p1 = plt.bar(ind, y,width)

plt.xticks(ind, x, fontsize=15, rotation=30)
plt.yticks(np.arange(22000, 24000, step=100),fontsize=15)
plt.ylim(bottom=22000, top = 23900)

plt.xlabel("Zip Code",labelpad=30,fontsize=20)
plt.ylabel("Total Transaction Value (USD)",labelpad=30,fontsize=20)

plt.title("Top 20 Zip Codes by Total Transaction Value", pad=20, fontsize=20)

plt.show()