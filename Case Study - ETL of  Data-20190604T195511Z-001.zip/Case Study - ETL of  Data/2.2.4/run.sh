hadoop fs -put -f workflow.xml /optimized_oozie
hadoop fs -put -f coordinator.xml /optimized_oozie

oozie job -oozie http://localhost:11000/oozie  -config  job.properties  -run