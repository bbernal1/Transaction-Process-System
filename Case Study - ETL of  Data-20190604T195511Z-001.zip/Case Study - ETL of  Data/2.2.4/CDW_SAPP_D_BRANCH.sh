sqoop job \
--meta-connect jdbc:hsqldb:hsql://localhost:16000/sqoop \
--delete updateBranch

sqoop job \
--meta-connect jdbc:hsqldb:hsql://localhost:16000/sqoop \
--create updateBranch \
-- import \
--connect jdbc:mysql://localhost/cdw_sapp --driver com.mysql.jdbc.Driver \
-m 1 \
--query \
"SELECT BRANCH_CODE, \
BRANCH_NAME, BRANCH_STREET, \
BRANCH_CITY, BRANCH_STATE, \
if (BRANCH_ZIP IS NOT NULL, LPAD(BRANCH_ZIP,5,'0'), 99999) as BRANCH_ZIP, \
concat('(',substring(BRANCH_PHONE,1,3),')', substring(BRANCH_PHONE,4,3),'-', substring(BRANCH_PHONE,7,4)) as BRANCH_PHONE, \
LAST_UPDATED \
from \
cdw_sapp.cdw_sapp_branch \
where \$CONDITIONS" \
--target-dir /Credit_Card_System/CDW_SAPP_D_BRANCH/ \
--append \
--incremental lastmodified \
--check-column LAST_UPDATED \
--last-value '0000-00-00 00:00:00' \
--fields-terminated-by '\t'