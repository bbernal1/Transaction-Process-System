hadoop fs -mkdir /optimized_oozie

hive -f createDatabase.hql 
sqoop metastore &
bash CDW_SAPP_D_BRANCH.sh
bash CDW_SAPP_F_CREDIT_CARD.sh
bash CDW_SAPP_D_TIME.sh
bash CDW_SAPP_D_CUSTOMER.sh

hadoop fs -put -f CDW_SAPP_D_BRANCH.hql /optimized_oozie
hadoop fs -put -f CDW_SAPP_F_CREDIT_CARD.hql /optimized_oozie
hadoop fs -put -f CDW_SAPP_D_TIME.hql /optimized_oozie
hadoop fs -put -f CDW_SAPP_D_CUSTOMER.hql /optimized_oozie
hadoop fs -put -f coordinator.xml /optimized_oozie
hadoop fs -put -f workflow.xml /optimized_oozie