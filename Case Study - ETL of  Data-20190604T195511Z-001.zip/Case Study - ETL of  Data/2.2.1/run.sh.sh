# Creates sqoop jobs and executes each jobs
bash CDW_SAPP_D_BRANCH.sh
bash CDW_SAPP_F_CREDIT_CARD.sh
bash CDW_SAPP_D_TIME.sh
bash CDW_SAPP_D_CUSTOMER.sh