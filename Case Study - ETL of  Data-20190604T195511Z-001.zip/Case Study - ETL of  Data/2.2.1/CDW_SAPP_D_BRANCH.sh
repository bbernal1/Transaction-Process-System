sqoop import \
--connect jdbc:mysql://localhost/cdw_sapp --driver com.mysql.jdbc.Driver \
-m 1 \
--query \
"SELECT BRANCH_CODE, BRANCH_NAME, BRANCH_STREET, BRANCH_CITY, BRANCH_STATE,
if (BRANCH_ZIP IS NOT NULL, LPAD(BRANCH_ZIP,5,'0'), 99999) as BRANCH_ZIP,
concat('(',substring(BRANCH_PHONE,1,3),')', substring(BRANCH_PHONE,4,3),'-', substring(BRANCH_PHONE,7,4)) as BRANCH_PHONE,
LAST_UPDATED
from
cdw_sapp.cdw_sapp_branch
where \$CONDITIONS" \
--delete-target-dir \
--target-dir /Credit_Card_System/CDW_SAPP_D_BRANCH/ \
--fields-terminated-by '\t'