hive -f CDW_SAPP_D_BRANCH.hql
hive -f CDW_SAPP_F_CREDIT_CARD.hql
hive -f CDW_SAPP_D_TIME.hql
hive -f CDW_SAPP_D_CUSTOMER.hql